import json
import sys

sys.path.insert(0, '../../qwen3vl_annotate260107')

from pathlib import Path
import os, json, copy, sys
from PIL import Image
import cv2


from parse_js import parse_s

def change_coord(x_pred,y_pred,w,h):
    x=x_pred/1000.*w
    y=y_pred/1000.*h
    return [int(x),int(y)]
def draw_som(image_path,box,outdir):
    x1,y1,x2,y2=box
    box_color = (255, 0, 255)

    thickness = 2
    image = cv2.imread(image_path)
    print(image.shape)
    img=cv2.rectangle(image, (x1, y1), (x2, y2), box_color, thickness)
    cv2.imwrite(outdir,img)


def get_w_h(image_path):
    image = cv2.imread(image_path)
    h,w,_=image.shape
    return w,h


img='/Users/yr/Desktop/notebook1/数据/系统数据/帮助手册/deepin-image-viewer/image-viewer/zh_CN/fig/info.png'
w,h=get_w_h(img)

outdir='/Users/yr/Desktop/notebook1/数据/系统数据/帮助手册/deepin-image-viewer/funcIcon_pos_annotate'
for fn in os.listdir(outdir):
    f=os.path.join(outdir,fn)
    d=json.load(open(f))
    outdic=parse_s(d['o'])
    pos=outdic['position']
    pos=eval(pos)
    x,y=pos

    x,y=change_coord(x,y,w,h)
    print(x,y)
    #####
    box=[x,y,x+5,y+5]
    draw_som(img,box,'./tmp.png')

