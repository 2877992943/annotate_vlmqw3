"""
vlm(icon_{功能},img)=pos能否成功 单图标注位置
如果能，放agent 获得轨迹，动态变化

如果能  然后 用helper_icon生成task ，icon_{功能}映射到 task -> [task,img, elem_pos] 不只是单图标注，是traj
"""

import base64
import mimetypes
import json
import sys

sys.path.insert(0,'../../qwen3vl_annotate260107')
 
from pathlib import Path
import os,json,copy,sys
from PIL import Image
import cv2
from req1_util import change_img,call_llm,encode_image_correctly_resize

from parse_js import parse_s




def judgedir(o):
    if not os.path.exists(o):
        os.mkdir(o)
def get_w_h(img):
    # 方法1：直接打开
    img = Image.open(img)
    width, height = img.size
    return width, height



prompt1="""you are given a image of app window and a image of icon, please decide whether the icon is in the window and where.
Structure your response in JSON format as shown below:
                        ```json
                        {{
                          "whether_exist":"",
                          "position":""
                        }}
please note that:
-if the icon cannot be find in the application window,return False in whether_exist column
-if the icon can be find in the application window, return the coordinate in position column
-just give your thinking briefly.
"""
 


if __name__=='__main__':
    # from argument1 import get_args
    # args=get_args()
    #iconsz=args.iconSize

    mdir="/Users/yr/Desktop/notebook1/数据/系统数据/帮助手册/"
    mdir="/mnt/data1/yr/DATA/usr-share-deepin-manual"
    imgdir=os.path.join(mdir,"deepin-image-viewer/image-viewer/zh_CN/fig/info.png")
    icondir=os.path.join(mdir,"deepin-image-viewer/image-viewer/common_png")
    outputdir=os.path.join(mdir,'deepin-image-viewer/funcIcon_pos_annotate')
    judgedir(outputdir)

    for icon in os.listdir(icondir):
        cc=[]
        if not icon.endswith('png'):continue
        icon_full=os.path.join(icondir,icon)
        ### txt
        cc.append({
            "type": "text",
            "text": prompt1
        })
        #### img
        dataurl = encode_image_correctly_resize(imgdir)
        cc.append({
            "type": "image_url",
            "image_url": {
                "url": dataurl
            }
        })
        ### icon
        dataurl = encode_image_correctly_resize(icon_full)
        cc.append({
            "type": "image_url",
            "image_url": {
                "url": dataurl
            }
        })
        messages = [{
            "role": "user",
            "content": cc}]


        out = call_llm(messages)
        print(out)

        #####
        ret={'img':imgdir,'icon':icon_full,'o':out,'prompt':prompt1}
        with open(os.path.join(outputdir, icon + '.json'), 'w') as w:
            json.dump(ret, w, indent=4, ensure_ascii=False)
        #print(done1)



