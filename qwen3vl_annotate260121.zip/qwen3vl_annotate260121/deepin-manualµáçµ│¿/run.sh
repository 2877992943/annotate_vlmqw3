

python helper_func_icon_annotate.py
