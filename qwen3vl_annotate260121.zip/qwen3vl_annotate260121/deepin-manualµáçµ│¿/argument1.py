
import argparse





def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--iconSize', default=None, type=str)

    return parser.parse_args()
