"""
1 crop context (仅拿出taskbar区域的targe patch) omnparse patch 保存
2 read icon
3 vlm 标注 patch



"""
import base64
import mimetypes
import json
from argument1 import get_args
 
from pathlib import Path
import os,json,copy,sys
from PIL import Image
import cv2
from req1_util import change_img,call_llm,encode_image_correctly
from prompts1 import text1

def norm2int(coord_norm, w, h):

    x, y = coord_norm
    x *= w
    y *= h
    coord = [x, y]
    #print(18,coord,w,h)
    return [int(v) for v in coord]


def crop_box_basic(png,inputImgdir,outputdir,outname, box):
    """
    基础版本：根据box坐标裁剪图像区域

    参数:
        image_path: 输入图像路径
        box: [x1, y1, x2, y2] 或 [x, y, w, h]
        save_path: 保存路径（可选）

    返回:
        cropped: 裁剪后的图像
    """
    # 读取图像
    image_path=os.path.join(inputImgdir,png)
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"无法读取图像: {image_path}")

    # 获取图像尺寸
    h, w = img.shape[:2]

    # 解析box坐标
    if len(box) == 4:
        #print(43,box)
        if box[2] > box[0] and box[3] > box[1]:  # [x1, y1, x2, y2]
            x1, y1, x2, y2 = map(int, box)
        # else:  # [x, y, w, h]
        #     x, y, width, height = map(int, box)
        #     x1, y1, x2, y2 = x, y, x + width, y + height
    else:
        raise ValueError("box 必须是包含4个值的列表")

    # 确保坐标在图像范围内
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)

    # 确保x2 > x1 且 y2 > y1
    if x2 <= x1 or y2 <= y1:
        raise ValueError(f"无效的box坐标: {box}",[x1,y1,x2,y2])

    # 裁剪图像
    #print(61,x1,x2,y1,y2)
    cropped = img[y1:y2, x1:x2]

    # 保存图像
    save_path=os.path.join(outputdir,outname)
    if 1:
        cv2.imwrite(save_path, cropped)
        print(f"裁剪区域已保存到: {save_path}")
        print(f"原始图像尺寸: {w}x{h}")
        print(f"裁剪区域尺寸: {cropped.shape[1]}x{cropped.shape[0]}")

    return cropped
def crop(png,inputImgdir,outpath,elemlist,w,h):
    retll=[]

    for elem in elemlist:
        normbox = elem['bbox']
        p1, p2 = norm2int(normbox[:2], w, h), norm2int(normbox[2:], w, h)
        # print(p1, p2)
        # print(coord_int)
        #if p1[0] <= coord_int[0] <= p2[0] and p1[1] <= coord_int[1] <= p2[1]:
        #### 如果 box的 h坐标在taskbar上 跳过
        if p1[1]<h-taskbar_region_h or p2[1]<h-taskbar_region_h:continue
        ### 画出图存储
        outname = png + f'{int(p1[0])}_{int(p1[1])}_{int(p2[0])}_{int(p2[1])}_crop.png'
        retll.append(outname)
        ####存 omnparse crop patch
        crop_box_basic(png,inputImgdir,outpath,outname, p1 + p2)
    return retll


def judgedir(o):
    if not os.path.exists(o):
        os.mkdir(o)
def get_w_h(img):
    # 方法1：直接打开
    img = Image.open(img)
    width, height = img.size
    return width, height

def main_crop():
    datall = json.load(open(infodir))
    retll = []
    #### step1 taskbar的区域 -> crop omnparse patch save
    for data in datall:
        imgpath = os.path.join(inputImgdir, data['img_new'])
        omnparse_path = os.path.join(omnparsedir, data['img_new'] + '.json')
        ##w,h=data['resolution'] ### 这个分辨率不对
        w, h = get_w_h(imgpath)
        ###
        omnparse_content = json.load(open(omnparse_path))
        outnamell = crop(data['img_new'], inputImgdir, outputPatchdir, omnparse_content, w, h)
        ###
        data['resolution_correct'] = [w, h]
        data['crop_name'] = outnamell
        retll.append(copy.copy(data))
        # break
    ####
    with open(infodir_, 'w') as w:
        json.dump(retll, w, indent=4, ensure_ascii=False)


 

if __name__=='__main__':
    args=get_args()
    assert args.iconSize!=None
    iconsize=str(args.iconSize)

    #p1='/mnt/data1/yr/DATA/uos-usr-share-icon-260106/新建文件夹-allpng/[bloom]_[96]_kget.svg.png'

    mdir='/mnt/data1/yr/data/api_annotate/uos_v260105_taskbar'
    inputImgdir=os.path.join(mdir,'allimg')
    allIconDir='/mnt/data1/yr/DATA/uos-usr-share-icon-260106/新建文件夹-allpng'### 所有主题和尺寸的图标png
    omnparsedir=os.path.join(mdir,'omnparse_out')## omnparse的 json结果
    infodir=os.path.join(mdir,'img_info.json')### resolution, theme
    infodir_ = os.path.join(mdir, 'img_info_crop.json')
    outputPatchdir=os.path.join(mdir,'omnparsePatch')### omnparse crop图片，target patch
    judgedir(outputPatchdir)
    outputjsDir=os.path.join(mdir,f'vlmAnnotate_{iconsize}')
    judgedir(outputjsDir)

    donelist=[f for f in os.listdir(outputjsDir) if f.endswith('json')]
    taskbar_region_h=40+10
    print(donelist)

    ##### crop 先把omnparse crop patch切出来 获得target patch
    #main_crop()

    #####  read icon
    print(160,iconsize)
    iconNamelist=[os.path.join(allIconDir,f) for f in os.listdir(allIconDir) if f.endswith('png') and f'[{iconsize}]' in f ][:]
    print('icon name list',len(iconNamelist))
    #print(done)
    #### vlm annotate
    ### message ## text |all icon| taskbar_omnparsePatch | text
    datall=json.load(open(infodir_))
    for data in datall:
        for target_patch_ in data['crop_name']:
            if target_patch_+'.json' in donelist:
                print('done this')
                continue
            cc=[]
            ### 一个targe patch from omnparse
            target_patch=os.path.join(outputPatchdir,target_patch_)
            if not os.path.exists(target_patch):
                print(done)
            cc.append({
                        "type": "text",
                        "text": text1
                    })
            #####
            # all icon
            for ix,iconpath in enumerate(iconNamelist):
                if not os.path.exists(iconpath):print(done)
                #dataurl,_,_=change_img(iconpath)
                #iconpath=p1
                dataurl=encode_image_correctly(iconpath)
                #print(173,iconpath)
                 
                cc.append({
                        "type": "text",
                        "text": f"icon index:{ix}"
                    })
                cc.append({
                        "type": "image_url",
                        "image_url": {
                            "url": dataurl
                        }
                    })
            #print(176,len(cc))
            #####
            # target patch in taskbar
            #dataurl, _, _ = change_img(target_patch)
            #target_patch=p1
            dataurl=encode_image_correctly(target_patch)
            print('target patch',target_patch)
            cc.append({
                "type": 'text',
                "text":"**target patch**: "
                    })
            cc.append({
                "type": "image_url",
                "image_url": {
                    "url": dataurl
                        }
                    })
            
            ####
            messages=[{
                "role": "user",
                "content":cc}]

            ####
            # with open('./tmp_crop.json','w') as w:
            #     json.dump(messages,w,indent=4,ensure_ascii=False)
            #print(messages)
            #print(done)
            out=call_llm(messages)
            print(out)
            
            o={'out':out,
            'iconnamelist':iconNamelist,'targetPatch':target_patch_,
            'iconsize':iconsize,
            'prompt':text1
            }
            with open(os.path.join(outputjsDir,target_patch_+'.json'),'w') as w:
                json.dump(o,w,indent=4,ensure_ascii=False)
            #print(done1)








