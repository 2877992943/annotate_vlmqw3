
import time
from openai import OpenAI
from prompts1 import text1
import json

img="https://pics0.baidu.com/feed/0b55b319ebc4b745f8aeb98be25ec4188b8215a2.jpeg@f_auto?token=29342cdc6630640d6c61d914d413e5c8"

client = OpenAI(
    api_key="EMPTY",
    base_url="http://10.83.115.4:22007/v1",
    #base_url="http://0.0.0.0:22007/v1",
    timeout=3600
)

from req1_util import change_img
p1='/mnt/data1/yr/DATA/uos-usr-share-icon-260106/新建文件夹-allpng/[bloom]_[96]_kget.svg.png'
p2='/mnt/data1/yr/data/api_annotate/uos_v260105_taskbar/omnparsePatch/vm_0_resolution1-themebloo_6c33edf6_20260105_164620_step_002.png1006_1016_1039_1048_crop.png'
img2,_,_=change_img(p2)
img1,_,_=change_img(p1)
ix=0
messages = [
    {
        "role": "user",
        "content": [
            {
                "type": "text",
                "text": text1
            },
            {
                        "type": "text",
                        "text": f"icon index:{ix}"
                    },
            {
                "type": "image_url",
                "image_url": {
                    "url": img1
                }
            },

            {
                "type": 'text',
                "text":"**target patch**: "
                    },
            {
                "type": "image_url",
                "image_url": {
                    "url": img2
                }
            },
           
            
        ]
    }
]
 
# with open('./tmp_req1_1.json','w') as w:
#     json.dump(messages,w,indent=4,ensure_ascii=False)

start = time.time()
response = client.chat.completions.create(
   # model="Qwen/Qwen3-VL-235B-A22B-Instruct-FP8",
   model="/data/share_d4/models/hub/Qwen3-VL-235B-A22B-Thinking",
    messages=messages,
    max_tokens=2048
)
print(f"Response costs: {time.time() - start:.2f}s")
print(f"Generated text: {response.choices[0].message.content}")