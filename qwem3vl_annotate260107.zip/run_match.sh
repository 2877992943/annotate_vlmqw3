
ll=(16 24 32)
#ll=(16)
for num in "${ll[@]}"; do
    echo "处理数字: $num"
    # 在这里添加你的处理逻辑
    python see_out_matchicon.py -s $num
done