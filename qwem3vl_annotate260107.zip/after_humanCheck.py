
"""

人工检查后
1 制作 icon2info 两个文件夹下
usr/share/applications/*desktop 和 var/lib/linglong/entries.app/share/*.desktop
 [img,box,iconInfo]

 2 人工检查的 omnparse patch 的 iconName 连接到 icon-info()


 3 针对泛化taskbar APP 数据的 数量分布 统计
"""
from collections import Counter
import os,json,sys,copy
#### 在本地
mdir="/Users/yr/Desktop/notebook1/数据/系统数据/usr-share系统图标20260105/两个文件夹下的usr-share-application和var-lib-linglong/"
fdir=os.path.join(mdir,"desktop-info1")
fdir1=os.path.join(mdir,"desktop-info2")
outjsdir=os.path.join(mdir,"iconName2info.json")
outjsdir_humanCheck=os.path.join(mdir,"omnparsePatch_iconName_iconInfo.json")
#### 在服务器上
mdir="/mnt/data1/yr/data/api_annotate/uos_v260105_taskbar/"
outjsdir_humanCheck=os.path.join(mdir,"omnparsePatch_iconName_iconInfo.json")
imgDir=os.path.join(mdir,"allimg")
outjsdir_meta=os.path.join(mdir,"metadata_g_general_theme_resolution_taskbarOrder.json")

keyll=['Icon=','GenericName[zh_CN]=','Name[zh_CN]=','Comment[zh_CN]=','Name=','Comment=']
import cv2
def main1():### 从两个目录 获得  iconName2info数据
    fn=[f for f in os.listdir(fdir) if f.endswith('desktop')]
    fn1=[f for f in os.listdir(fdir1) if f.endswith('desktop')]

    ll={}
    def func(fn,fdir):
        for f in fn:
            this_icon={}
            for line in open(os.path.join(fdir,f)).readlines():

                for key in keyll:
                    if key in line:
                        c=line.replace(key,'').strip()
                        this_icon[key]=c
                        break
            ####
            if this_icon and 'Icon=' in this_icon:
                iconname=this_icon['Icon=']
                ll[f'{iconname}.svg.png']=this_icon
    func(fn,fdir)
    func(fn1,fdir1)




    with open(outjsdir,'w') as w:
        json.dump(ll,w,indent=4,ensure_ascii=False)
######
## 从两个目录 获得  iconName2info数据
#main1()

def main2():
    ###### 将标注好的 omnparse patch，映射到 iconinfo
    iconName2info=json.load(open(outjsdir))
    humanCheckDir="/Users/yr/Desktop/notebook1/code/GUI/ANNOTATE_process218/qwen3vl_annotate260107/匹配数据/vlmAnnotate_16_match"
    totallist=[]
    cnt_icon2number=[]
    for themeSzIcon in os.listdir(humanCheckDir):
        if not '[16]' in themeSzIcon:continue
        iconName1=themeSzIcon.split('[16]_')[-1]
        if iconName1+'.svg.png' not in iconName2info:
            print(f'没有这个icon的 info .....{iconName1}')
            continue
        iconInfo=iconName2info[iconName1+'.svg.png']
        nameZH=iconInfo['Name='] if 'Name[zh_CN]=' not in iconInfo else iconInfo['Name[zh_CN]=']
        for omnparsePatch in os.listdir(os.path.join(humanCheckDir,themeSzIcon)):
            if not omnparsePatch.endswith('png'):continue
            totallist.append({'omnparsePatch':omnparsePatch,'iconinfo':iconInfo,'iconName':iconName1})
            cnt_icon2number.append(nameZH)
    #####
    with open(outjsdir_humanCheck,'w') as w:
        json.dump(totallist,w,indent=4,ensure_ascii=False)
    ####
    c=Counter(cnt_icon2number)
    print(c)
#main2()

def main3_mk_meta():### 制作  双语  利用 name, comment 的数据
    datall=json.load(open(outjsdir_humanCheck))
    trainll=[]

    def get_w_h(imgpath):
        image = cv2.imread(imgpath)
        h, w, _ = image.shape
        return w,h
    def get_norm_center(box, w, h):
        x, y, x1, y1 = box
        x /= w
        x1 /= w
        y /= h
        y1 /= h
        norm_box = [x, y, x1, y1]
        norm_point = [x / 2. + x1 / 2., y / 2. + y1 / 2.];  # print(norm_box,norm_point)
        norm_box = [round(v, 4) for v in norm_box]
        norm_point = [round(v, 4) for v in norm_point]
        return norm_point, norm_box
    def make_cell_II(png,instruction,normpoint,normbox):#### uitars的 grounding数据格式 没有思考 Action:xxxx
        x,y=normpoint
        return {
            'task':instruction,
            "dataflag":"grounding",
            "image":png,
            "conversations": [
                {
                    "from": "human",
                    "value": f"<image>",
                    "loss_mask": 0
                },
                {
                    "from": "gpt",
                    # "value": "pyautogui.click(x=0.1835, y=0.7955)",###  原始gui-actor
                    "value": 'Action:'+f"click(start_box='<|box_start|>(x={x}, y={y})<|box_end|>')",  ### 使用uitars格式
                    "recipient": "os",
                    "end_turn": True,
                    "bbox_gt":normbox,
                    "bbox_gt_end":None,
                    "loss_mask": 1
                }
            ]
        }
    ###### normbox ,normpoint, text -> meta data
    for data in datall:
        omnparsePatch=data['omnparsePatch']
        png=omnparsePatch.split('.png')[0]+'.png'
        x,y,x1,y1,_=omnparsePatch.split('.png')[1].split('_')
        box=[x,y,x1,y1]
        box=[int(v) for v in box]
        imgpath=os.path.join(imgDir,png)
        w,h=get_w_h(imgpath)
        ##
        norm_point, norm_box=get_norm_center(box,w,h)
        ## text: name comment
        info=data['iconinfo']
        namezh=info.get('Name[zh_CN]=',None)
        commentzh=info.get('Comment[zh_CN]=',None)
        name = info.get('Name=', None)
        comment = info.get('Comment=', None)
        namegeneZH=info.get('GenericName[zh_CN]=',None)
        if namegeneZH==namezh:
            namegeneZH=None
        for txt in [namezh,commentzh,name,comment,namegeneZH]:
            if txt:
                d=make_cell_II(png,txt,norm_point,norm_box)
                d['raw']=copy.copy(data)
                trainll.append(copy.copy(d))
        #break

    #####
    print('total train',len(trainll))
    with open(outjsdir_meta,'w') as w:
        json.dump(trainll,w,indent=4,ensure_ascii=False)


main3_mk_meta()
