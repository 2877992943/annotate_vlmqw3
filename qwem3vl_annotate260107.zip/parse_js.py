

import json
import os


def parse_s(line):
    if "```json" in line:
        l=line.split("```json\n")[1]
        l=l.strip("\n```")
        try:
            tmp=json.loads(l)

            return tmp
        except:
            return None
            #print(25,[l])
            #print(done)
    elif "</think>\n" in line:
        l=line.split("</think>\n")[1].strip()
        return json.loads(l)

