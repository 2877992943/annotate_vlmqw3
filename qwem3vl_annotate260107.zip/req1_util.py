import base64
import time
from openai import OpenAI
from pathlib import Path
from PIL import Image
import base64
import mimetypes
import json

client = OpenAI(
    api_key="EMPTY",
    base_url="http://10.83.115.4:22007/v1",
    #base_url="http://0.0.0.0:22007/v1",
    timeout=3600
)

def demo():
    img = "https://pics0.baidu.com/feed/0b55b319ebc4b745f8aeb98be25ec4188b8215a2.jpeg@f_auto?token=29342cdc6630640d6c61d914d413e5c8"
    messages = [
    {
        "role": "user",
        "content": [
            {
                "type": "image_url",
                "image_url": {
                    "url": img
                }
            },
            {
                "type": "text",
                "text": "Read all the text in the image."
            }
        ]
    }
]

    start = time.time()
    response = client.chat.completions.create(
       # model="Qwen/Qwen3-VL-235B-A22B-Instruct-FP8",
       model="/data/share_d4/models/hub/Qwen3-VL-235B-A22B-Thinking",
        messages=messages,
        max_tokens=2048
    )
    print(f"Response costs: {time.time() - start:.2f}s")
    print(f"Generated text: {response.choices[0].message.content}")


def call_llm(messages):
    response = client.chat.completions.create(
        # model="Qwen/Qwen3-VL-235B-A22B-Instruct-FP8",
        model="/data/share_d4/models/hub/Qwen3-VL-235B-A22B-Thinking",
        messages=messages,
        max_tokens=20480
    )
    return response.choices[0].message.content


def change_img(image_path):
    """将图片转换为 base64
    url3,w,h = change_img('./1.png')
    content={
                        "type": "image_url",
                        "image_url": {
                            "url": url3
                        }
                    }
    """
    suffix = Path(image_path).suffix.lower().lstrip('.')
    if suffix == 'jpg':
        suffix = 'jpeg'
    with open(image_path, 'rb') as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
    data_url = f"data:image/{suffix};base64,{encoded_string}"
    ###
    # 2. 获取图片宽高（使用 PIL）
    with Image.open(image_path) as img:
        width, height = img.size
    return data_url,width,height





def encode_image_correctly(image_path):
    """
    正确编码本地图片为base64
    """
    # 1. 读取图片文件
    with open(image_path, "rb") as image_file:
        image_data = image_file.read()
    
    # 2. 获取MIME类型
    mime_type, _ = mimetypes.guess_type(image_path)
    if mime_type is None:
        # 根据文件扩展名判断
        ext = Path(image_path).suffix.lower()
        if ext in ['.jpg', '.jpeg']:
            mime_type = 'image/jpeg'
        elif ext == '.png':
            mime_type = 'image/png'
        elif ext == '.gif':
            mime_type = 'image/gif'
        elif ext == '.webp':
            mime_type = 'image/webp'
        else:
            mime_type = 'image/jpeg'
    
    # 3. 编码并构建URL
    encoded_string = base64.b64encode(image_data).decode('utf-8')
    return f"data:{mime_type};base64,{encoded_string}"