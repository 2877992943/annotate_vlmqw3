
"""
看 模型标注结果
对每个尺寸大小
omnparsePatch -> iconName -> 每个iconname的omnparsPatch放到一个文件夹下人工检查

"""
import json
import os
from argument1 import get_args
import shutil

# def parse_s(s):
#     cleaned_json_str = s.split('\n',1)[1].strip('```')
#     return cleaned_json_str
def parse_s(line):
    if "```json" in line:
        l=line.split("```json\n")[1]
        l=l.strip("\n```")
        try:
            tmp=json.loads(l)

            return tmp
        except:
            return None
            #print(25,[l])
            #print(done)
    elif "</think>\n" in line:
        l=line.split("</think>\n")[1].strip()
        return json.loads(l)

def judgedir(o):
    if not os.path.exists(o):
        os.mkdir(o)


args=get_args()
cnt=0
iconsz=args.iconSize
omparsePatchDir='/mnt/data1/yr/data/api_annotate/uos_v260105_taskbar/omnparsePatch'
mdir='/mnt/data1/yr/data/api_annotate/uos_v260105_taskbar'
vlmAnnotate_result=os.path.join(mdir,f'vlmAnnotate_{iconsz}')
outputdir=os.path.join(mdir,f'vlmAnnotate_{iconsz}_match')## 每个 iconname下有 omparsePatch 人工检查
judgedir(outputdir)
outjs=os.path.join(outputdir,'iconName2omnparsPatch.json')
iconName2omnparsePatch={}

for fn in os.listdir(vlmAnnotate_result):
    #fn='vm_0_resolution0-themebloo_829cfe10_20260105_145059_step_002.png754_1048_781_1074_crop.png.json'
    f=os.path.join(vlmAnnotate_result,fn)
    data=json.load(open(f))
    out=data['out']
    iconnamelist=data['iconnamelist']
    targetPatch=data['targetPatch']
    targetPatch_full=os.path.join(omparsePatchDir,targetPatch)
    #print([out])


    d=parse_s(out)
    if d==None:continue
    print(d)
    if d['icon_index_number'].strip()=='':continue
    iconNum=int(d['icon_index_number'])
    icon_in_set=iconnamelist[iconNum]
    print(icon_in_set)
    #/mnt/data1/yr/DATA/uos-usr-share-icon-260106/新建文件夹-allpng/[bloom]_[16]_deepin-multitasking-view.svg.png
    iconName=icon_in_set.split('/')[-1]
    if iconName not in iconName2omnparsePatch:
        iconName2omnparsePatch[iconName]=[]
    iconName2omnparsePatch[iconName].append(targetPatch)
    cnt+=1
    #### 新建文件夹 iconname
    iconDir=iconName.replace('.svg.png','')
    judgedir(os.path.join(outputdir,iconDir))
    ##### 搬运图片
    source=targetPatch_full
    dest=os.path.join(outputdir,iconDir,targetPatch)
    shutil.copy(source,dest)
    #break
#####
print(f'总共匹配出omnparse patch{cnt}')
with open(outjs,'w') as w:
    json.dump(iconName2omnparsePatch,w,indent=4,ensure_ascii=False)





