"""
系统图标
DATA/uos-usr-share-icon-260106

1 增加启动器 图标
1.1增加启动器 iconName2info

2 所有svg尺寸里的，->去重名称， ->变成24大小的图标
每个主题内部各个尺寸去重图标名称。统一 iconNameSet

https://modelscope.cn/datasets/yr2877992943/usr-share-icon20260106/resolve/master/%E7%B3%BB%E7%BB%9F%E5%9B%BE%E6%A0%87-20260106-v2.zip
"""