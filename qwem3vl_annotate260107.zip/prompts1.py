




text1="""
you are given a set of GUI icons and a target patch, you need to choose which one of the set of icons is mostly involved in target patch.

##The set of GUI icon is given in below format:
icon index:0
icon image
icon index:1
icon image
...

##The target patch is given in below format:
**target patch**: image

Structure your response in JSON format as shown below:
                        ```json
                        {{
                          "whether_exist":"",
                          "icon_index_number":""
                        }}
please note that:
if there is no one in the set of icons look like the target patch or included in the target patch, return None in "whether_exist" column.
if there is many more in the set of icons look like the target patch or involved in the target patch, return one icon index in "icon_index_number" column.
no need to give reason, give answer in JSON format directly
"""


text0119="""
you are given a set of GUI icons and a target patch, you need to choose which one of the set of icons is mostly involved with target patch or look like the target patch.

##The set of GUI icon is given in the first image and labeled with row number. you are asked to decide the target icon is in which row and return the row number.

##The target patch is given in below format:
**target patch**: image


Structure your response in JSON format as shown below:
                        ```json
                        {{
                          "whether_exist":"",
                          "row_number":""
                        }}
                        
please note that:
if there is no one in the set of icons look like the target patch or included in the target patch, return None in "whether_exist" column.
if there is many more in the set of icons look like the target patch or involved in the target patch, return one icon index in "icon_index_number" column.
no need to give reason, give answer in JSON format directly

"""