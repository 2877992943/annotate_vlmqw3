
import time
from openai import OpenAI


img="https://pics0.baidu.com/feed/0b55b319ebc4b745f8aeb98be25ec4188b8215a2.jpeg@f_auto?token=29342cdc6630640d6c61d914d413e5c8"

client = OpenAI(
    api_key="EMPTY",
    base_url="http://10.83.115.4:22007/v1",
    #base_url="http://0.0.0.0:22007/v1",
    timeout=3600
)



messages = [
    {
        "role": "user",
        "content": [
            {
                "type": "image_url",
                "image_url": {
                    "url": img
                }
            },
            # {
            #     "type": "image_url",
            #     "image_url": {
            #         "url": img
            #     }
            # },
            {
                "type": "text",
                "text": "reason and describe image"
            }
        ]
    }
]

start = time.time()
response = client.chat.completions.create(
   # model="Qwen/Qwen3-VL-235B-A22B-Instruct-FP8",
   model="/data/share_d4/models/hub/Qwen3-VL-235B-A22B-Thinking",
    messages=messages,
    max_tokens=2048
)
print(f"Response costs: {time.time() - start:.2f}s")
print(f"Generated text: {response.choices[0].message.content}")